<?php $this->load->view('school_competitive_exams/competitive_include/head');?>

<body class="home page-template-default page page-id-6208 gdlr-core-body tribe-no-js kingster-body kingster-body-front kingster-full kingster-with-sticky-navigation kingster-sticky-navigation-no-logo kingster-blockquote-style-1 gdlr-core-link-to-lightbox" >
<?php $this->load->view('school_competitive_exams/competitive_include/mobile-header');?>
    <div class="kingster-body-outer-wrapper">
        <div class="kingster-body-wrapper clearfix kingster-with-transparent-header kingster-with-frame">
            <div class="kingster-header-background-transparent">
          <?php $this->load->view('school_competitive_exams/competitive_include/topbar');?>
          <?php $this->load->view('school_competitive_exams/competitive_include/header');?>
 
                <!-- header -->
            </div>


            <div class="kingster-page-wrapper" id="kingster-page-wrapper">
                <div class="gdlr-core-page-builder-body">
                    <div class="gdlr-core-pbf-wrapper " style="padding: 600px 0px 60px 0px;" id="gdlr-core-wrapper-1">
                        <div class="gdlr-core-pbf-background-wrap">
                            <div class="gdlr-core-pbf-background gdlr-core-parallax gdlr-core-js" style="background-image: url(<?php echo base_url(); ?>school_competitive_exams/images/ANNOUNCEMENTS.jpg) ;background-size: cover ;background-position: center ;" data-parallax-speed="0">
                            </div>
                        </div>
                        <div class="gdlr-core-page-builder-wrapper-top-gradient" style="height: 413px ;background: linear-gradient(rgba(0, 0, 0, 100), rgba(0, 0, 0, 0));-moz-background: linear-gradient(rgba(0, 0, 0, 100), rgba(0, 0, 0, 0));-o-background: linear-gradient(rgba(0, 0, 0, 100), rgba(0, 0, 0, 0));-webkit-background: linear-gradient(rgba(0, 0, 0, 100), rgba(0, 0, 0, 0));">
                        </div>
                        <div class="gdlr-core-page-builder-wrapper-bottom-gradient" style="height: 413px ;background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 100));-moz-background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 100));-o-background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 100));-webkit-background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 100));">
                        </div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-column gdlr-core-column-20 gdlr-core-column-first">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" style="padding-bottom: 20px ;">
                                                    <div class="gdlr-core-title-item-title-wrap clearfix">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title " style="font-weight: 700 ;letter-spacing: 0px ;text-transform: none ;color: #ffffff ;">Announcement</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-divider-item gdlr-core-divider-item-normal gdlr-core-item-pdlr gdlr-core-left-align">
                                                    <div class="gdlr-core-divider-container" style="max-width: 385px ;">
                                                        <div class="gdlr-core-divider-line gdlr-core-skin-divider" style="border-color: #0082fa ;border-width: 5px;">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-40">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" style="padding-bottom: 0px ;">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 18px ;text-transform: none ;color: #ffffff ;">
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gdlr-core-pbf-wrapper " style="padding: 70px 0px 30px 0px;" data-skin="Blut Title Column Service">
                        <div class="gdlr-core-pbf-background-wrap">
                        </div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                        
                                <div class="gdlr-core-pbf-element">
                                    <div class="gdlr-core-blog-item gdlr-core-item-pdb clearfix gdlr-core-style-blog-column" style="padding-bottom: 0px ;">
                                        <div class="gdlr-core-block-item-title-wrap gdlr-core-left-align gdlr-core-item-mglr" style="margin-bottom: 40px ;">
                                            <div class="gdlr-core-block-item-title-inner clearfix">
                                                <h3 class="gdlr-core-block-item-title" style="font-size: 24px ;font-style: normal ;text-transform: none ;letter-spacing: 0px ;color: #163269 ;">Announcements</h3>
                                                <div class="gdlr-core-block-item-title-divider" style="font-size: 24px ;border-bottom-width: 2px ;">
                                                </div>
                                            </div>
                                            <!--<a class="gdlr-core-block-item-read-more" href="#" target="_self" style="color: #3db166 ;">Read All News</a>-->
                                        </div>
                                        <div class="gdlr-core-blog-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
										<?php $i=0; if(isset($news)){	foreach($news as $n1){ 
										
											$en_news_id=base64_encode($n1["web_news_id"]);?>
                                            <div class="gdlr-core-item-list gdlr-core-item-pdlr gdlr-core-column-20 ">
                                                <div class="gdlr-core-blog-grid ">
                                                   <!-- <div class="gdlr-core-blog-thumbnail gdlr-core-media-image gdlr-core-opacity-on-hover gdlr-core-zoom-on-hover">
                                                <?php if($n1["web_news_image"]==""){?>
                                                                            <img src="upload/shutterstock_62838724-900x500.jpg" width="900" height="500" alt="" />
                                                                     
																		<?php  } else{?>
																	
                                                                            <img src="<?php echo base_url(); ?>news_images/<?php echo $n1["web_news_image"];?>" width="900" height="500" alt="" />
                                                                    
																		<?php }?>  </div>-->
                                                    <div class="gdlr-core-blog-grid-content-wrap">
                                                        <div class="gdlr-core-blog-info-wrapper gdlr-core-skin-divider">
                                                            <span class="gdlr-core-blog-info gdlr-core-blog-info-font gdlr-core-skin-caption gdlr-core-blog-info-date"><a href="#"><?php echo  date("d M, Y",strtotime($n1["web_news_date"]));?></a></span><span class="gdlr-core-blog-info gdlr-core-blog-info-font gdlr-core-skin-caption gdlr-core-blog-info-category"><a href="#" rel="tag"><?php echo $n1["news_category"]?></a></span>
                                                        </div>
                                                        <h3 class="gdlr-core-blog-title gdlr-core-skin-title" style="font-size: 17px ;font-weight: 600 ;letter-spacing: 0px ;"><a href="#"><?php echo ucwords($n1["web_news_head"])?></a></h3>
                                                        <div class="gdlr-core-blog-content clearfix">
                                                            <a class="gdlr-core-excerpt-read-more gdlr-core-button gdlr-core-rectangle" href="<?php echo base_url(); ?>school_competitive_exams/home/announcement_in_detail/<?php echo $en_news_id?>">Read More</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
											<?php $i++;}} if($i==0){?>
                                            <div class="gdlr-core-item-list gdlr-core-item-pdlr gdlr-core-column-20">
                                                <div class="gdlr-core-blog-grid ">
                                                    <div class="gdlr-core-blog-thumbnail gdlr-core-media-image gdlr-core-opacity-on-hover gdlr-core-zoom-on-hover">
                                                       <!-- <a href="#"><img src="upload/shutterstock_62838724-900x500.jpg" alt="" width="900" height="500" title="shutterstock_62838724"/></a>-->
                                                    </div>
                                                    <div class="gdlr-core-blog-grid-content-wrap">
                                                       <!-- <div class="gdlr-core-blog-info-wrapper gdlr-core-skin-divider">
                                                            <span class="gdlr-core-blog-info gdlr-core-blog-info-font gdlr-core-skin-caption gdlr-core-blog-info-date"><a href="#">June 6, 2016</a></span><span class="gdlr-core-blog-info gdlr-core-blog-info-font gdlr-core-skin-caption gdlr-core-blog-info-category"><a href="#" rel="tag">Masonry</a></span>
                                                        </div>-->
                                                        <h3 class="gdlr-core-blog-title gdlr-core-skin-title" style="font-size: 17px ;font-weight: 600 ;letter-spacing: 0px ;"><a href="#">No Announcement</a></h3>
                                                      <!--  <div class="gdlr-core-blog-content clearfix">
                                                            <a class="gdlr-core-excerpt-read-more gdlr-core-button gdlr-core-rectangle" href="#">Read More</a>
                                                        </div>-->
                                                    </div>
                                                </div>
                                            </div>
											<?php }?>
                                       
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--<div class="gdlr-core-pbf-wrapper " style="padding: 125px 0px 70px 0px;">
                        <div class="gdlr-core-pbf-background-wrap">
                            <div class="gdlr-core-pbf-background gdlr-core-parallax gdlr-core-js" style="background-image: url(upload/alumni-about-bg.jpg) ;background-size: cover ;background-position: center ;" data-parallax-speed="0.2">
                            </div>
                        </div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-column gdlr-core-column-20 gdlr-core-column-first">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix gdlr-core-left-align gdlr-core-title-item-caption-bottom gdlr-core-item-pdlr" style="padding-bottom: 20px ;">
                                                    <div class="gdlr-core-title-item-title-wrap clearfix">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title " style="font-size: 31px ;font-weight: 600 ;letter-spacing: 0px ;text-transform: none ;color: #51be78 ;">Kingster Alumni</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-40">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" style="padding-bottom: 15px ;">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 23px ;text-transform: none ;color: #d8e3fb ;">
                                                        <p>
                                                            We are one of the largest, most diverse universities in the USA with over 90,000 students in USA, and a further 30,000 studying across 180 countries for Kingster University.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" style="padding-bottom: 15px ;">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 19px ;font-weight: 500 ;text-transform: none ;color: #ffffff ;">
                                                        <p>
                                                            Kingster University was established by John Smith in 1920 for the public benefit and it is recognized globally. Throughout our great history, Kingster has offered access to a wide range of academic opportunities. As a world leader in higher education, the University has pioneered change in the sector.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-button-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align">
                                                    <a class="gdlr-core-button gdlr-core-button-transparent gdlr-core-left-align gdlr-core-button-no-border" href="#" id="gdlr-core-button-id-32692"><span class="gdlr-core-content">Read More</span><i class="gdlr-core-pos-right fa fa-long-arrow-right" style="font-size: 18px ;color: #ffffff ;"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>-->
                   <!-- <div class="gdlr-core-pbf-wrapper " style="padding: 90px 0px 30px 0px;">
                        <div class="gdlr-core-pbf-background-wrap">
                        </div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-element">
                                    <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" style="padding-bottom: 40px ;">
                                        <div class="gdlr-core-title-item-title-wrap clearfix">
                                            <h3 class="gdlr-core-title-item-title gdlr-core-skin-title " style="font-size: 24px ;font-weight: 700 ;letter-spacing: 0px ;text-transform: none ;">Enjoy Benefits & Privileges</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-20 gdlr-core-column-first">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js " style="padding-bottom: 20px;">
                                        <div class="gdlr-core-pbf-background-wrap">
                                        </div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-image-item gdlr-core-item-pdb gdlr-core-center-align gdlr-core-item-pdlr" style="padding-bottom: 33px ;">
                                                    <div class="gdlr-core-image-item-wrap gdlr-core-media-image gdlr-core-image-item-style-round" style="border-width: 0px;border-radius: 2px;-moz-border-radius: 2px;-webkit-border-radius: 2px;">
                                                        <a class="gdlr-core-lightgallery gdlr-core-js " href="upload/dan-gold-105699-unsplash.jpg"><img src="upload/dan-gold-105699-unsplash-900x500.jpg" alt="" width="900" height="500" title="dan-gold-105699-unsplash"/><span class="gdlr-core-image-overlay " style="border-radius: 2px;-moz-border-radius: 2px;-webkit-border-radius: 2px;"><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"></i></span></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" style="padding-bottom: 20px ;">
                                                    <div class="gdlr-core-title-item-title-wrap clearfix">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title " style="font-size: 18px ;font-weight: 600 ;letter-spacing: 0px ;text-transform: none ;">15% Off For Restaurant in KU</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" style="padding-bottom: 2px ;">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 16px ;text-transform: none ;color: #8f8f8f ;">
                                                        <p>
                                                            Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Dudenmouth.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-button-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align">
                                                    <a class="gdlr-core-button gdlr-core-button-transparent gdlr-core-left-align gdlr-core-button-no-border" href="#" style="font-size: 16px ;font-weight: 400 ;letter-spacing: 0px ;color: #0082fa ;padding: 0px 0px 0px 0px;text-transform: none ;border-radius: 0px;-moz-border-radius: 0px;-webkit-border-radius: 0px;"><span class="gdlr-core-content">Read More</span><i class="gdlr-core-pos-right arrow_right" style="font-size: 21px ;color: #0082fa ;"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-20">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js " style="padding: 0px 0px 20px 0px;">
                                        <div class="gdlr-core-pbf-background-wrap">
                                        </div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-image-item gdlr-core-item-pdb gdlr-core-center-align gdlr-core-item-pdlr" style="padding-bottom: 33px ;">
                                                    <div class="gdlr-core-image-item-wrap gdlr-core-media-image gdlr-core-image-item-style-round" style="border-width: 0px;border-radius: 2px;-moz-border-radius: 2px;-webkit-border-radius: 2px;">
                                                        <a class="gdlr-core-lightgallery gdlr-core-js " href="upload/shutterstock_167044400.jpg"><img src="upload/shutterstock_167044400-900x500.jpg" alt="" width="900" height="500" title="shutterstock_167044400"/><span class="gdlr-core-image-overlay " style="border-radius: 2px;-moz-border-radius: 2px;-webkit-border-radius: 2px;"><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"></i></span></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" style="padding-bottom: 20px ;">
                                                    <div class="gdlr-core-title-item-title-wrap clearfix">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title " style="font-size: 18px ;font-weight: 600 ;letter-spacing: 0px ;text-transform: none ;">40% Off KU Fitness</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" style="padding-bottom: 2px ;">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 16px ;text-transform: none ;color: #8f8f8f ;">
                                                        <p>
                                                            Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Dudenmouth.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-button-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align">
                                                    <a class="gdlr-core-button gdlr-core-button-transparent gdlr-core-left-align gdlr-core-button-no-border" href="#" style="font-size: 16px ;font-weight: 400 ;letter-spacing: 0px ;color: #0082fa ;padding: 0px 0px 0px 0px;text-transform: none ;border-radius: 0px;-moz-border-radius: 0px;-webkit-border-radius: 0px;"><span class="gdlr-core-content">Read More</span><i class="gdlr-core-pos-right arrow_right" style="font-size: 21px ;color: #0082fa ;"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-20">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js " style="padding: 0px 0px 20px 0px;">
                                        <div class="gdlr-core-pbf-background-wrap">
                                        </div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-image-item gdlr-core-item-pdb gdlr-core-center-align gdlr-core-item-pdlr" style="padding-bottom: 33px ;">
                                                    <div class="gdlr-core-image-item-wrap gdlr-core-media-image gdlr-core-image-item-style-round" style="border-width: 0px;border-radius: 2px;-moz-border-radius: 2px;-webkit-border-radius: 2px;">
                                                        <a class="gdlr-core-lightgallery gdlr-core-js " href="upload/shutterstock_160526219.jpg"><img src="upload/shutterstock_160526219-900x500.jpg" alt="" width="900" height="500" title="shutterstock_160526219"/><span class="gdlr-core-image-overlay " style="border-radius: 2px;-moz-border-radius: 2px;-webkit-border-radius: 2px;"><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"></i></span></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" style="padding-bottom: 20px ;">
                                                    <div class="gdlr-core-title-item-title-wrap clearfix">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title " style="font-size: 18px ;font-weight: 600 ;letter-spacing: 0px ;text-transform: none ;">Free Library Access</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" style="padding-bottom: 2px ;">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 16px ;text-transform: none ;color: #8f8f8f ;">
                                                        <p>
                                                            Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Dudenmouth.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-button-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align">
                                                    <a class="gdlr-core-button gdlr-core-button-transparent gdlr-core-left-align gdlr-core-button-no-border" href="#" style="font-size: 16px ;font-weight: 400 ;letter-spacing: 0px ;color: #0082fa ;padding: 0px 0px 0px 0px;text-transform: none ;border-radius: 0px;-moz-border-radius: 0px;-webkit-border-radius: 0px;"><span class="gdlr-core-content">Read More</span><i class="gdlr-core-pos-right arrow_right" style="font-size: 21px ;color: #0082fa ;"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>-->
                   <!-- <div class="gdlr-core-pbf-wrapper " style="margin: 0px auto 0px auto;padding: 0px 0px 0px 0px;max-width: 100% ;">
                        <div class="gdlr-core-pbf-background-wrap" style="background-color: #192f59 ;">
                        </div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js " data-gdlr-animation="fadeIn" data-gdlr-animation-duration="600ms" data-gdlr-animation-offset="0.8">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-column gdlr-core-column-30 gdlr-core-column-first">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js gdlr-core-column-extend-left" data-sync-height="height-1">
                                        <div class="gdlr-core-pbf-background-wrap">
                                            <div class="gdlr-core-pbf-background gdlr-core-parallax gdlr-core-js" style="background-image: url(upload/shutterstock_166604900.jpg) ;background-size: cover ;background-position: center ;" data-parallax-speed="0">
                                            </div>
                                        </div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js gdlr-core-sync-height-content">
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-30">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js " style="padding: 140px 0px 90px 75px;" data-sync-height="height-1" data-sync-height-center>
                                        <div class="gdlr-core-pbf-background-wrap">
                                        </div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js gdlr-core-sync-height-content">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix gdlr-core-left-align gdlr-core-title-item-caption-bottom gdlr-core-item-pdlr">
                                                    <div class="gdlr-core-title-item-title-wrap clearfix">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title " style="font-size: 35px ;font-weight: 700 ;letter-spacing: 0px ;text-transform: none ;color: #ffffff ;">Steve Cook</h3>
                                                    </div>
                                                    <span class="gdlr-core-title-item-caption gdlr-core-info-font gdlr-core-skin-caption" style="font-weight: 500 ;font-style: normal ;color: #3db166 ;">CEO, Apple and MBA, Kingster</span>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" style="padding-bottom: 20px ;">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 18px ;text-transform: none ;color: #ffffff ;">
                                                        <p>
                                                            One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and divided by arches into stiff sections. The bedding was hardly able to cover it and seemed ready to slide off any moment. Housed in a nice, gilded frame.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>-->
                </div>
            </div>

                <?php $this->load->view('school_competitive_exams/competitive_include/footer');?>
        </div>
    </div>



    <script src="<?php echo base_url(); ?>school_competitive_exams/js/jquery/jquery.js" id="jquery-core-js"></script>
    <script src="<?php echo base_url(); ?>school_competitive_exams/js/kingster-learnpress.js" id="kingster-learnpress-js"></script>
    <script>
        ( function ( body ) {
            'use strict';
            body.className = body.className.replace( /\btribe-no-js\b/, 'tribe-js' );
        } )( document.body );
    </script>
    <script>
        /* <![CDATA[ */var tribe_l10n_datatables = {"aria":{"sort_ascending":": activate to sort column ascending","sort_descending":": activate to sort column descending"},"length_menu":"Show _MENU_ entries","empty_table":"No data available in table","info":"Showing _START_ to _END_ of _TOTAL_ entries","info_empty":"Showing 0 to 0 of 0 entries","info_filtered":"(filtered from _MAX_ total entries)","zero_records":"No matching records found","search":"Search:","all_selected_text":"All items on this page were selected. ","select_all_link":"Select all pages","clear_selection":"Clear Selection.","pagination":{"all":"All","next":"Next","previous":"Previous"},"select":{"rows":{"0":"","_":": Selected %d rows","1":": Selected 1 row"}},"datepicker":{"dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesMin":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Prev","currentText":"Today","closeText":"Done","today":"Today","clear":"Clear"}};/* ]]> */
    </script>
    <script src="<?php echo base_url(); ?>school_competitive_exams/js/script.js" id="gdlr-core-plugin-js"></script>
    <script id="gdlr-core-page-builder-js-extra">
        /* <![CDATA[ */
        var gdlr_core_pbf = {"admin":"","video":{"width":"640","height":"360"},"ajax_url":"#"};
        /* ]]> */
    </script>
    <script src="<?php echo base_url(); ?>school_competitive_exams/js/page-builder.js" id="gdlr-core-page-builder-js"></script>
    <script src="<?php echo base_url(); ?>school_competitive_exams/js/jquery/ui/effect.min.js" id="jquery-effects-core-js"></script>
    <script id="kingster-script-core-js-extra">
        /* <![CDATA[ */
        var kingster_script_core = {"home_url":""};
        /* ]]> */
    </script>
    <script src="<?php echo base_url(); ?>school_competitive_exams/js/script-core.js" id="kingster-script-core-js"></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>school_competitive_exams/js/isotope.js'></script>
</body>
</html>