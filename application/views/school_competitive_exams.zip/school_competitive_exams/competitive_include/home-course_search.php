
                    <div class="gdlr-core-pbf-wrapper" style="padding: 0px 0px 0px 0px;">
                        <div class="gdlr-core-pbf-background-wrap"></div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                             <!--   <div class="gdlr-core-pbf-column gdlr-core-column-60 gdlr-core-column-first" id="gdlr-core-column-50996">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js" style="padding-bottom: 135px;">
                                        <div class="gdlr-core-pbf-background-wrap"></div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-gallery-item gdlr-core-item-pdb clearfix gdlr-core-gallery-item-style-grid" style="padding-bottom: 0px;">
                                                    <div class="gdlr-core-gallery-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                                                        <div class="gdlr-core-item-list gdlr-core-gallery-column gdlr-core-column-15 gdlr-core-column-first gdlr-core-item-pdlr gdlr-core-item-mgb" style="margin-bottom: 0px;">
                                                            <div class="gdlr-core-gallery-list gdlr-core-media-image"><img src="upload/items4.png" alt="" width="500" height="203" title="items4" /></div>
                                                        </div>
                                                        <div class="gdlr-core-item-list gdlr-core-gallery-column gdlr-core-column-15 gdlr-core-item-pdlr gdlr-core-item-mgb" style="margin-bottom: 0px;">
                                                            <div class="gdlr-core-gallery-list gdlr-core-media-image"><img src="upload/items3.png" alt="" width="500" height="203" title="items3" /></div>
                                                        </div>
                                                        <div class="gdlr-core-item-list gdlr-core-gallery-column gdlr-core-column-15 gdlr-core-item-pdlr gdlr-core-item-mgb" style="margin-bottom: 0px;">
                                                            <div class="gdlr-core-gallery-list gdlr-core-media-image"><img src="upload/items2.png" alt="" width="500" height="203" title="items2" /></div>
                                                        </div>
                                                        <div class="gdlr-core-item-list gdlr-core-gallery-column gdlr-core-column-15 gdlr-core-item-pdlr gdlr-core-item-mgb" style="margin-bottom: 0px;">
                                                            <div class="gdlr-core-gallery-list gdlr-core-media-image"><img src="upload/items1.png" alt="" width="500" height="203" title="items1" /></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>-->
                                <div class="gdlr-core-pbf-column gdlr-core-column-30 gdlr-core-column-first gdlr-core-hide-in-mobile" id="gdlr-core-column-23044" style="z-index: 9;">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js" style="margin: -50px -70px 0px -50px; padding: 0px 0px 0px 0px;">
                                        <div class="gdlr-core-pbf-background-wrap"></div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-image-item gdlr-core-item-pdb gdlr-core-center-align gdlr-core-item-pdlr" style="padding-bottom: 0px;">
                                                    <div class="gdlr-core-image-item-wrap gdlr-core-media-image gdlr-core-image-item-style-rectangle" style="border-width: 0px; max-width: 576px;">
                                                        <img src="upload/Women-25.png" alt="" width="876" height="993" title="Women 25" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-30" data-skin="Course color" id="gdlr-core-column-42138">
                                    <div
                                        class="gdlr-core-pbf-column-content-margin gdlr-core-js"
                                        style="
                                            box-shadow: 0px 30px 50px rgba(3, 15, 39, 0.1);
                                            -moz-box-shadow: 0px 30px 50px rgba(3, 15, 39, 0.1);
                                            -webkit-box-shadow: 0px 30px 50px rgba(3, 15, 39, 0.1);
                                            margin-top: -50px;
                                            margin-bottom: 0px;
                                            margin-left: -50px;
                                            padding: 70px 40px 65px 40px;
                                            border-radius: 7px 7px 7px 7px;
                                            -moz-border-radius: 7px 7px 7px 7px;
                                            -webkit-border-radius: 7px 7px 7px 7px;
                                        "
                                    >
                                        <div class="gdlr-core-pbf-background-wrap" style="background-color: #ffffff; border-radius: 7px 7px 7px 7px; -moz-border-radius: 7px 7px 7px 7px; -webkit-border-radius: 7px 7px 7px 7px;"></div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix gdlr-core-center-align gdlr-core-title-item-caption-bottom gdlr-core-item-pdlr" style="padding-bottom: 45px;">
                                                    <div class="gdlr-core-title-item-title-wrap clearfix">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title" style="font-size: 28px; font-weight: 400; color: #222222;">Search For Courses</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-course-search-item gdlr-core-item-pdb gdlr-core-item-pdlr" style="padding-bottom: 0px;">
                                                    <form class="gdlr-core-course-form clearfix" action="https://demo.goodlayers.com/kingster/homepages/college/course-search/" method="GET">
                                                        <div class="gdlr-core-course-column gdlr-core-column-30 gdlr-core-column-first">
                                                            <div class="gdlr-core-course-search-field gdlr-core-course-field-keywords"><input type="text" placeholder="Keywords" name="course-keywords" value="" /></div>
                                                        </div>
                                                        <div class="gdlr-core-course-column gdlr-core-column-30">
                                                            <div class="gdlr-core-course-search-field gdlr-core-course-field-course-id"><input type="text" placeholder="Course ID" name="course-id" value="" /></div>
                                                        </div>
                                                        <div class="gdlr-core-course-column gdlr-core-column-30 gdlr-core-column-first">
                                                            <div class="gdlr-core-course-search-field gdlr-core-course-field-department">
                                                                <div class="gdlr-core-course-form-combobox gdlr-core-skin-e-background">
                                                                    <select class="gdlr-core-skin-e-content" name="department">
                                                                        <option value="">Department</option>
                                                                        <option value="business-adminstration">Business Adminstration</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gdlr-core-course-column gdlr-core-column-30">
                                                            <div class="gdlr-core-course-search-field gdlr-core-course-field-campus">
                                                                <div class="gdlr-core-course-form-combobox gdlr-core-skin-e-background">
                                                                    <select class="gdlr-core-skin-e-content" name="campus">
                                                                        <option value="">Campus</option>
                                                                        <option value="admans-hall">Adman's Hall</option>
                                                                        <option value="kingsters-80">Kingster's 80</option>
                                                                        <option value="ku2-hill">KU2 Hill</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gdlr-core-course-column gdlr-core-column-30 gdlr-core-column-first">
                                                            <div class="gdlr-core-course-search-field gdlr-core-course-field-level">
                                                                <div class="gdlr-core-course-form-combobox gdlr-core-skin-e-background">
                                                                    <select class="gdlr-core-skin-e-content" name="level">
                                                                        <option value="">Level</option>
                                                                        <option value="graduate">Graduate</option>
                                                                        <option value="undergraduate">Undergraduate</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gdlr-core-course-column gdlr-core-column-30">
                                                            <div class="gdlr-core-course-search-field gdlr-core-course-field-instructor">
                                                                <div class="gdlr-core-course-form-combobox gdlr-core-skin-e-background">
                                                                    <select class="gdlr-core-skin-e-content" name="instructor">
                                                                        <option value="">Instructor</option>
                                                                        <option value="albert-coman-phd">Albert Coman (PhD)</option>
                                                                        <option value="angelina-jones-phd">Angelina Jones (PhD)</option>
                                                                        <option value="bruce-willis-phd">Bruce Willis (PhD)</option>
                                                                        <option value="carol-dawson-phd">Carol Dawson (PhD)</option>
                                                                        <option value="john-hagensy">John Hagensy (PhD)</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gdlr-core-course-column gdlr-core-column-30 gdlr-core-column-first">
                                                            <div class="gdlr-core-course-search-field gdlr-core-course-field-semester">
                                                                <div class="gdlr-core-course-form-combobox gdlr-core-skin-e-background">
                                                                    <select class="gdlr-core-skin-e-content" name="semester">
                                                                        <option value="">Semester</option>
                                                                        <option value="fall-2018">Fall 2018</option>
                                                                        <option value="spring-2019">Spring 2019</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gdlr-core-course-column gdlr-core-column-30">
                                                            <div class="gdlr-core-course-search-field gdlr-core-course-field-credit">
                                                                <div class="gdlr-core-course-form-combobox gdlr-core-skin-e-background">
                                                                    <select class="gdlr-core-skin-e-content" name="credit">
                                                                        <option value="">Credit</option>
                                                                        <option value="2-000">2.000</option>
                                                                        <option value="3-000">3.000</option>
                                                                        <option value="4-000">4.000</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gdlr-core-course-form-submit gdlr-core-course-column gdlr-core-column-first gdlr-core-center-align">
                                                            <input class="gdlr-core-auto-size" type="submit" value="Search Courses" />
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>