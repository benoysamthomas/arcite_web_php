            <div class="gdlr-core-pbf-wrapper" style="padding: 100px 0px 40px 0px;" id="gdlr-core-wrapper-3">
                        <div class="gdlr-core-pbf-background-wrap"></div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-column gdlr-core-column-30 gdlr-core-column-first" id="gdlr-core-column-43113">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js" data-sync-height="Kingster College height">
                                        <div class="gdlr-core-pbf-background-wrap"></div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js gdlr-core-sync-height-content" style="max-width: 600px;">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-divider-item gdlr-core-divider-item-normal gdlr-core-item-pdlr gdlr-core-left-align gdlr-core-style-vertical" style="margin-bottom: 50px;">
                                                    <div class="gdlr-core-divider-line gdlr-core-skin-divider" style="border-color: #d1d1d1; height: 100px;"></div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr">
                                                    <span
                                                        class="gdlr-core-title-item-caption gdlr-core-info-font gdlr-core-skin-caption"
                                                        style="font-size: 15px; font-style: normal; letter-spacing: 1px; text-transform: uppercase; color: #999999;"
                                                    >
                                                        The ARCITE History
                                                    </span>
                                                    <div class="gdlr-core-title-item-title-wrap clearfix">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title" style="font-size: 42px; font-weight: 400; letter-spacing: 0px; color: #222222;">
                                                            We welcome you to learn more about us
                                                        </h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" style="padding-bottom: 0px;">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 18px; font-weight: 400; letter-spacing: 0px; text-transform: none; color: #373737;">
                                                        <p>
                                                     The ARC Institute of Technical Education (ARCITE) is a technical facility that offers education on a variety of job-related courses to college students and young hopefuls seeking assistance on further education and training.  </p>
                                                    </div>
                                                </div>
                                            </div>
											        <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-button-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-center-align" style="padding-bottom: 0px;">
                                                    <a
                                                        class="gdlr-core-button gdlr-core-button-gradient gdlr-core-center-align gdlr-core-button-no-border"
                                                        href="<?php echo base_url(); ?>school_competitive_exams/about_us"
                                                        style="
                                                            font-size: 13px;
                                                            font-weight: 600;
                                                            letter-spacing: 1px;
                                                            color: #ffffff;
                                                            padding: 17px 38px 17px 38px;
                                                            text-transform: uppercase;
                                                            border-radius: 4px;
                                                            -moz-border-radius: 4px;
                                                            -webkit-border-radius: 4px;
                                                            background: #0082fa;
                                                        "
                                                    >
                                                        <span class="gdlr-core-content">Learn About Us</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-30" id="gdlr-core-column-70394">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js" style="margin-top: 100px; margin-bottom: 0px; margin-left: -20px; padding-top: 0px; padding-bottom: 0px;">
                                        <div class="gdlr-core-pbf-background-wrap"></div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-image-item gdlr-core-item-pdb gdlr-core-center-align gdlr-core-item-pdlr" style="padding-bottom: 0px;">
                                                    <div class="gdlr-core-image-item-wrap gdlr-core-media-image gdlr-core-image-item-style-rectangle" style="border-width: 0px;">
                                                        <img src="<?php echo base_url(); ?>school_competitive_exams/images/home_about_us.jpg" alt="" width="834" height="660" title="classroom" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>