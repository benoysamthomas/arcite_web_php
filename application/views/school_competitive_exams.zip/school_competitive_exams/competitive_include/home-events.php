
					                    <div class="gdlr-core-pbf-wrapper" style="padding: 100px 0px 300px 0px; z-index: 9;">
                        <div class="gdlr-core-pbf-background-wrap" style="background-color: #f3f3f3;">
                            <div
                                class="gdlr-core-pbf-background gdlr-core-parallax gdlr-core-js"
                                style="background-image: url(upload/Blog01.jpg); background-repeat: no-repeat; background-position: top center;"
                                data-parallax-speed="0.15"
                            ></div>
                        </div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-wrapper-container-inner gdlr-core-item-mglr clearfix" style="margin: 0px 0px -200px 0px; z-index: 9; width: 100%;">
                                    <div class="gdlr-core-pbf-column gdlr-core-column-30 gdlr-core-column-first" id="gdlr-core-column-33303">
                                        <div class="gdlr-core-pbf-column-content-margin gdlr-core-js" style="padding-top: 0px; padding-bottom: 15px;">
                                            <div class="gdlr-core-pbf-background-wrap"></div>
                                            <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js">
                                                <div class="gdlr-core-pbf-element">
                                                    <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix gdlr-core-left-align gdlr-core-title-item-caption-bottom gdlr-core-item-pdlr" style="padding-bottom: 40px;">
                                                        <div class="gdlr-core-title-item-title-wrap clearfix">
                                                            <h3 class="gdlr-core-title-item-title gdlr-core-skin-title" style="font-size: 28px; font-weight: 400; letter-spacing: 0px; color: #222222;">upcoming events</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="gdlr-core-pbf-element">
                                                    <div class="gdlr-core-button-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align">
                                                        <a
                                                            class="gdlr-core-button gdlr-core-button-transparent gdlr-core-left-align gdlr-core-button-with-border"
                                                            href="#"
                                                            style="
                                                                font-size: 13px;
                                                                font-weight: 600;
                                                                letter-spacing: 1px;
                                                                color: #222222;
                                                                padding: 0px 0px 2px 0px;
                                                                text-transform: uppercase;
                                                                border-radius: 0px;
                                                                -moz-border-radius: 0px;
                                                                -webkit-border-radius: 0px;
                                                                border-width: 0px 0px 1px 0px;
                                                                border-color: #c5c5c5;
                                                            "
                                                        >
                                                            <span class="gdlr-core-content">View All Events</span><i class="gdlr-core-pos-right fa fa-long-arrow-right" style="font-size: 15px; color: #222222;"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gdlr-core-pbf-column gdlr-core-column-30">
                                        <div class="gdlr-core-pbf-column-content-margin gdlr-core-js"><div class="gdlr-core-pbf-column-content clearfix gdlr-core-js"></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					                    <div class="gdlr-core-pbf-wrapper" style="margin-top: -258px; padding: 0px 0px 100px 0px;">
                        <div class="gdlr-core-pbf-background-wrap"></div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-column gdlr-core-column-60 gdlr-core-column-first" id="gdlr-core-column-78730" style="z-index: 9;">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js" style="padding-top: 0px;">
                                        <div class="gdlr-core-pbf-background-wrap"></div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-event-item gdlr-core-item-pdb" style="padding-bottom: 0px;">
                                                    <div class="gdlr-core-event-item-holder clearfix">
                                                        <div class="gdlr-core-event-item-list gdlr-core-item-pdlr gdlr-core-style-grid2 gdlr-core-column-20 gdlr-core-with-frame gdlr-core-column-first clearfix">
                                                            <div
                                                                class="gdlr-core-event-item-list-inner"
                                                                style="box-shadow: 0 30px 50px rgba(10, 10, 10, 0.1); -moz-box-shadow: 0 30px 50px rgba(10, 10, 10, 0.1); -webkit-box-shadow: 0 30px 50px rgba(10, 10, 10, 0.1);"
                                                            >
                                                                <div class="gdlr-core-event-item-thumbnail">
                                                                    <a href="#">
                                                                        <img src="upload/shutterstock_170053697-700x450.jpg" alt="" width="700" height="450" title="shutterstock_170053697" />
                                                                    </a>
                                                                </div>
                                                                <div class="gdlr-core-frame gdlr-core-skin-e-background gdlr-core-js" data-sync-height="event-item-1">
                                                                    <span class="gdlr-core-event-item-info gdlr-core-skin-caption gdlr-core-type-start-time"><span class="gdlr-core-tail">7 January 2020</span></span>
                                                                    <div class="gdlr-core-event-item-content-wrap">
                                                                        <h3 class="gdlr-core-event-item-title" style="text-transform: uppercase;">
                                                                            <a href="#">Reunion Event : Kingster’s Alumni Golf Tour</a>
                                                                        </h3>
                                                                        <div class="gdlr-core-event-item-info-wrap">
                                                                            <span class="gdlr-core-event-item-info gdlr-core-skin-caption gdlr-core-type-time">
                                                                                <span class="gdlr-core-head"><i class="icon_clock_alt"></i></span><span class="gdlr-core-tail">7:00 am - 11:30 pm</span>
                                                                            </span>
                                                                            <span class="gdlr-core-event-item-info gdlr-core-skin-caption gdlr-core-type-location">
                                                                                <span class="gdlr-core-head"><i class="icon_pin_alt"></i></span><span class="gdlr-core-tail">Kingster Grand Hall</span>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gdlr-core-event-item-list gdlr-core-item-pdlr gdlr-core-style-grid2 gdlr-core-column-20 gdlr-core-with-frame clearfix">
                                                            <div
                                                                class="gdlr-core-event-item-list-inner"
                                                                style="box-shadow: 0 30px 50px rgba(10, 10, 10, 0.1); -moz-box-shadow: 0 30px 50px rgba(10, 10, 10, 0.1); -webkit-box-shadow: 0 30px 50px rgba(10, 10, 10, 0.1);"
                                                            >
                                                                <div class="gdlr-core-event-item-thumbnail">
                                                                    <a href="#">
                                                                        <img src="upload/iStock-478707462-700x450.jpg" alt="" width="700" height="450" title="iStock-478707462" />
                                                                    </a>
                                                                </div>
                                                                <div class="gdlr-core-frame gdlr-core-skin-e-background gdlr-core-js" data-sync-height="event-item-1">
                                                                    <span class="gdlr-core-event-item-info gdlr-core-skin-caption gdlr-core-type-start-time"><span class="gdlr-core-tail">1 January 2020</span></span>
                                                                    <div class="gdlr-core-event-item-content-wrap">
                                                                        <h3 class="gdlr-core-event-item-title" style="text-transform: uppercase;">
                                                                            <a href="#">Kingster’s Alumni Hot Air Ballon Trip in Turkey</a>
                                                                        </h3>
                                                                        <div class="gdlr-core-event-item-info-wrap">
                                                                            <span class="gdlr-core-event-item-info gdlr-core-skin-caption gdlr-core-type-time">
                                                                                <span class="gdlr-core-head"><i class="icon_clock_alt"></i></span><span class="gdlr-core-tail">10:00 am - 4:30 pm</span>
                                                                            </span>
                                                                            <span class="gdlr-core-event-item-info gdlr-core-skin-caption gdlr-core-type-location">
                                                                                <span class="gdlr-core-head"><i class="icon_pin_alt"></i></span><span class="gdlr-core-tail">Kingster Grand Hall</span>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gdlr-core-event-item-list gdlr-core-item-pdlr gdlr-core-style-grid2 gdlr-core-column-20 gdlr-core-with-frame clearfix">
                                                            <div
                                                                class="gdlr-core-event-item-list-inner"
                                                                style="box-shadow: 0 30px 50px rgba(10, 10, 10, 0.1); -moz-box-shadow: 0 30px 50px rgba(10, 10, 10, 0.1); -webkit-box-shadow: 0 30px 50px rgba(10, 10, 10, 0.1);"
                                                            >
                                                                <div class="gdlr-core-event-item-thumbnail">
                                                                    <a href="#">
                                                                        <img src="upload/iStock-949466640-700x450.jpg" alt="" width="700" height="450" title="iStock-949466640" />
                                                                    </a>
                                                                </div>
                                                                <div class="gdlr-core-frame gdlr-core-skin-e-background gdlr-core-js" data-sync-height="event-item-1">
                                                                    <span class="gdlr-core-event-item-info gdlr-core-skin-caption gdlr-core-type-start-time"><span class="gdlr-core-tail">17 December 2019</span></span>
                                                                    <div class="gdlr-core-event-item-content-wrap">
                                                                        <h3 class="gdlr-core-event-item-title" style="text-transform: uppercase;">
                                                                            <a href="#">Fintech &amp; Key Investment Conference</a>
                                                                        </h3>
                                                                        <div class="gdlr-core-event-item-info-wrap">
                                                                            <span class="gdlr-core-event-item-info gdlr-core-skin-caption gdlr-core-type-time">
                                                                                <span class="gdlr-core-head"><i class="icon_clock_alt"></i></span><span class="gdlr-core-tail">1:00 pm - 5:00 pm</span>
                                                                            </span>
                                                                            <span class="gdlr-core-event-item-info gdlr-core-skin-caption gdlr-core-type-location">
                                                                                <span class="gdlr-core-head"><i class="icon_pin_alt"></i></span><span class="gdlr-core-tail">Kingster Grand Hall</span>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>