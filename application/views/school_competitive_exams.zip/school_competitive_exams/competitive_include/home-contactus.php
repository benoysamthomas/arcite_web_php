                    <div class="gdlr-core-pbf-wrapper" style="padding: 100px 0px 100px 0px;" id="gdlr-core-wrapper-2">
                        <div class="gdlr-core-pbf-background-wrap">
                            <div
                                class="gdlr-core-pbf-background gdlr-core-parallax gdlr-core-js"
                                style="background-image: url(<?php echo base_url(); ?>school_competitive_exams/images/home_contact_us.jpg); background-size: cover; background-position: center;"
                                data-parallax-speed="0"
                            ></div>
                        </div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-column gdlr-core-column-60 gdlr-core-column-first" id="gdlr-core-column-88905">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js">
                                        <div class="gdlr-core-pbf-background-wrap"></div>
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js" style="max-width: 700px;">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix gdlr-core-center-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" style="padding-bottom: 60px;">
                                                    <span
                                                        class="gdlr-core-title-item-caption gdlr-core-info-font gdlr-core-skin-caption"
                                                        style="font-size: 15px; font-style: normal; letter-spacing: 1px; text-transform: uppercase; color: #ffffff;"
                                                    >
                                                        We welcome you to learn more about us
                                                    </span>
                                                    <div class="gdlr-core-title-item-title-wrap clearfix">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title" style="font-size: 50px; font-weight: 400; color: #ffffff;">We’re always happy to hear from you</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-button-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-center-align" style="padding-bottom: 0px;">
                                                    <a
                                                        class="gdlr-core-button gdlr-core-button-gradient gdlr-core-center-align gdlr-core-button-no-border"
                                                        href="<?php echo base_url(); ?>school_competitive_exams/contact_us"
                                                        style="
                                                            font-size: 13px;
                                                            font-weight: 600;
                                                            letter-spacing: 1px;
                                                            color: #ffffff;
                                                            padding: 17px 38px 17px 38px;
                                                            text-transform: uppercase;
                                                            border-radius: 4px;
                                                            -moz-border-radius: 4px;
                                                            -webkit-border-radius: 4px;
                                                            background: #0082fa;
                                                        "
                                                    >
                                                        <span class="gdlr-core-content">Contact Us</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>