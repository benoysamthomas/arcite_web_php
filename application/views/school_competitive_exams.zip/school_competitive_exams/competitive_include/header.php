               <header class="kingster-header-wrap kingster-header-style-plain kingster-style-splitted-menu kingster-sticky-navigation kingster-style-slide clearfix" data-navigation-offset="75px">
                    <div class="kingster-header-background"></div>
                    <div class="kingster-header-container kingster-container">
                        <div class="kingster-header-container-inner clearfix">
                            <div class="kingster-navigation kingster-item-pdlr clearfix">
                                <div class="kingster-main-menu" id="kingster-main-menu">
                                    <ul id="menu-main-navigation-1" class="sf-menu">
									<li>
									<div class="kingster-logo kingster-item-pdlr">
                                                <div class="kingster-logo-inner" style="max-width:200px;padding-left:0px;">
                                                    <a class="" href="<?php echo base_url(); ?>school_competitive_exams/home"><img src="<?php echo base_url(); ?>school_competitive_exams/images/ARCITE_COMPETITIVE_WHITE.png" alt="" width="200" height="200" title="logo ARCITE Competitive" /></a>
                                                </div>
                                            </div>
									</li>
                                        <li class="menu-itemmenu-item-home <?php if($menu==1){ echo 'current-menu-item'; }?>  page_item page-item-6208 current_page_item  kingster-normal-menu">
                                            <a href="<?php echo base_url(); ?>school_competitive_exams/home">Home</a>
                                        </li>
										 <li class="menu-item kingster-normal-menu <?php if($menu==2){ echo 'current-menu-item'; }?>"><a href="#">Bookstore</a></li>
										 <li class="menu-item kingster-normal-menu <?php if($menu==3){ echo 'current-menu-item'; }?>"><a href="<?php echo base_url(); ?>enquiry_form/competitive_school_enquiry" target="_blank">Registration</a></li>
                                        <!--<li class="menu-item menu-item-has-children  kingster-normal-menu">
                                            <a href="#" class="sf-with-ul-pre">Pages</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item" data-size="60"><a href="about-us.html">About KU</a></li>
                                                <li class="menu-item" data-size="60"><a href="contact.html">Contact</a></li>
                                                <li class="menu-itemmenu-item-has-children " data-size="60">
                                                    <a href="portfolio-3-columns.html" class="sf-with-ul-pre">Portfolio</a>
                                                    <ul class="sub-menu">
                                                        <li class="menu-item menu-item-has-children ">
                                                            <a class="sf-with-ul-pre">Portfolio Grid</a>
                                                            <ul class="sub-menu">
                                                                <li class="menu-item"><a href="portfolio-2-columns.html">Portfolio 2 Columns</a></li>
                                                                <li class="menu-item"><a href="portfolio-3-columns.html">Portfolio 3 Columns</a></li>
                                                                <li class="menu-item"><a href="portfolio-4-columns.html">Portfolio 4 Columns</a></li>
                                                                <li class="menu-item"><a href="portfolio-5-columns.html">Portfolio 5 Columns</a></li>
                                                            </ul>
                                                        </li>
                                                        <li class="menu-item menu-item-has-children ">
                                                            <a class="sf-with-ul-pre">Portfolio Masonry</a>
                                                            <ul class="sub-menu">
                                                                <li class="menu-item"><a href="portfolio-masonry-4-columns.html">Masonry 4 Columns</a></li>
                                                                <li class="menu-item"><a href="portfolio-masonry-3-columns.html">Masonry 3 Columns</a></li>
                                                                <li class="menu-item"><a href="portfolio-masonry-2-columns.html">Masonry 2 Columns</a></li>
                                                            </ul>
                                                        </li>
                                                        <li class="menu-item menu-item-has-children ">
                                                            <a class="sf-with-ul-pre">Portfolio Side Thumbnail</a>
                                                            <ul class="sub-menu">
                                                                <li class="menu-item">
                                                                    <a href="portfolio-left-large-thumbnail.html">Portfolio Left Large Thumbnail</a>
                                                                </li>
                                                                <li class="menu-item">
                                                                    <a href="portfolio-right-large-thumbnail.html">Portfolio Right Large Thumbnail</a>
                                                                </li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="menu-item" data-size="60"><a href="gallery.html">Gallery</a></li>
                                                <li class="menu-item" data-size="60"><a href="price-table.html">Price Table</a></li>
                                                <li class="menu-item" data-size="60"><a href="maintenance.html">Maintenance</a></li>
                                                <li class="menu-item" data-size="60"><a href="coming-soon.html">Coming Soon</a></li>
                                                <li class="menu-item " data-size="60"><a href="404.html">404 Page</a></li>
                                            </ul>
                                        </li>-->
                                       <!-- <li class="menu-itemmenu-item-has-children  kingster-mega-menu">
                                            <a href="bachelor-of-science-in-business-administration.html" class="sf-with-ul-pre">Academics</a>
                                            <div class="sf-mega sf-mega-full" style="background-image: url('upload/mega-menu-bg.jpg'); background-position: bottom right; background-repeat: no-repeat;">
                                                <ul class="sub-menu">
                                                    <li class="menu-item menu-item-has-children " data-size="15">
                                                        <a class="sf-with-ul-pre">Undergraduate</a>
                                                        <ul class="sub-menu">
                                                            <li class="menu-item">
                                                                <a href="bachelor-of-science-in-business-administration.html">Business Administration</a>
                                                            </li>
                                                            <li class="menu-item"><a href="school-of-law.html">School Of Law</a></li>
                                                            <li class="menu-item"><a href="engineering.html">Engineering</a></li>
                                                            <li class="menu-item"><a href="medicine.html">Medicine</a></li>
                                                            <li class="menu-item"><a href="art-science.html">Art &#038; Science</a></li>
                                                        </ul>
                                                    </li>
                                                    <li class="menu-item menu-item-has-children " data-size="15">
                                                        <a href="#" class="sf-with-ul-pre">Graduate Program</a>
                                                        <ul class="sub-menu">
                                                            <li class="menu-item"><a href="hospitality-management.html">Hospitality Management</a></li>
                                                            <li class="menu-item"><a href="physics.html">Physics</a></li>
                                                            <li class="menu-item "><a href="#">Chemistry</a></li>
                                                            <li class="menu-item "><a href="#">Computer Science</a></li>
                                                        </ul>
                                                    </li>
                                                    <li class="menu-item menu-item-has-children " data-size="15">
                                                        <a href="#" class="sf-with-ul-pre">Resources</a>
                                                        <ul class="sub-menu">
                                                            <li class="menu-item"><a href="bachelor-of-science-in-business-administration.html">Department Page</a></li>
                                                            <li class="menu-item">
                                                                <a href="finance.html">Major Page</a>
                                                            </li>
                                                            <li class="menu-item">
                                                                <a href="finance-faculty.html">Faculty Page</a>
                                                            </li>
                                                            <li class="menu-item "><a href="introduction-to-financial-accounting.html">Single Course</a></li>
                                                        </ul>
                                                    </li>
                                                    <li class="menu-item " data-size="15">
                                                        <div class="kingster-mega-menu-section-content">
                                                            <img src="upload/menu-logo.png" style="margin-bottom: 13px;" alt="" /><br />
                                                            <span style="font-size: 14px; font-weight: 500;">Academic offerings include 95 majors, 86 minors, and more than 100 in-major specializations</span>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>-->
                                        <!--<li class="menu-itemmenu-item-has-children  kingster-normal-menu">
                                            <a href="apply-to-kingster.html" class="sf-with-ul-pre">Admissions</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item" data-size="60"><a href="apply-to-kingster.html">Apply To Kingster</a></li>
                                                <li class="menu-item" data-size="60"><a href="campus-tour.html">Campus Tour</a></li>
                                                <li class="menu-item" data-size="60"><a href="scholarships.html">Scholarships</a></li>
                                                <li class="menu-item" data-size="60"><a href="athletics.html">Athletics</a></li>
                                                <li class="menu-item" data-size="60"><a href="give-to-kingster.html">Give To Kingster</a></li>
                                                <li class="menu-item" data-size="60"><a href="alumni.html">Alumni</a></li>
                                                <li class="menu-item" data-size="60"><a href="event-calendar.html">Event Calendar</a></li>
                                            </ul>
                                        </li>-->
                                        <li class="kingster-center-nav-menu-item">
                                           <!-- <div class="kingster-logo kingster-item-pdlr">
                                                <div class="kingster-logo-inner" style="max-width:200px;">
                                                    <a class="" href="<?php echo base_url(); ?>school_competitive_exams/home"><img src="<?php echo base_url(); ?>school_competitive_exams/images/ARCITE_COMPETITIVE_BLACK.png" alt="" width="200" height="200" title="logo ARCITE Competitive" /></a>
                                                </div>
                                            </div>-->
                                        </li>
                                        <!--<li class="menu-item menu-item-has-children  kingster-normal-menu">
                                            <a href="course-list-1.html" class="sf-with-ul-pre">Courses</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item" data-size="60"><a href="course-list-1.html">Course List 1</a></li>
                                                <li class="menu-item" data-size="60"><a href="course-list-2.html">Course List 2</a></li>
                                            </ul>
                                        </li>-->
                                        <li class="menu-itemmenu-item-has-children  kingster-normal-menu <?php if($menu==4){ echo 'current-menu-item'; }?>">
                                            <a href="<?php echo base_url(); ?>school_competitive_exams/course_search" class="sf-with-ul-pre">Courses</a>
                                            <ul class="sub-menu">
											<?php 
											$i=1;
													$j=1;
											$dept=$this->home_model->get_department_by_institution(ARC_COMP_SCHOOL);
											foreach($dept as $dt){
												$en_dept_id=base64_encode($dt["web_dept_id"]);
												?> 
                                                <li class="menu-itemmenu-item-has-children  <?php if($dept_menu==$i){ echo 'current-menu-item'; }?>" data-size="60">
												
                                                    <a href="<?php echo base_url(); ?>school_competitive_exams/course_search/course_dept/<?php echo $i?>/<?php echo $en_dept_id ?>" class="sf-with-ul-pre"><?php echo $dt["web_dept_name"]?></a>
											
												   <ul class="sub-menu">
												   	<?php 
												$crse_name="";
												$mode_of_train=0;
												$durtn=0;
												
												$crse_list=$this->home_model->get_course_detials($crse_name,$mode_of_train,$durtn,$dt["web_dept_id"]);
														  if(isset($crse_list)){
								foreach($crse_list as $cs){
									
									$en_course_id=base64_encode($cs["web_course_id"]);
												?>
                                                        <li class="menu-item <?php if($course_menu==$j){ echo 'current-menu-item'; }?>">
														<a href="<?php echo base_url(); ?>school_competitive_exams/course_search/course_details/<?php echo $i?>/<?php echo $j?>/<?php echo $en_course_id ?>"><?php echo $cs["web_course_name"];?></a></li>
														
								<?php  $j++;
								}
														  }?>
                                                    </ul>
                                                </li>
													<?php  $i++;
													}?>
                                            </ul>
                                        </li>
										 <li class="menu-item kingster-normal-menu <?php if($menu==5){ echo 'current-menu-item'; }?>"><a href="#">Downloads</a></li>
										 <li class="menu-item kingster-normal-menu <?php if($menu==6){ echo 'current-menu-item'; }?>"><a href="<?php echo base_url(); ?>school_competitive_exams/home/announcements">Announcements</a></li>
                                    </ul>
                                </div>
                               <!-- <div class="kingster-main-menu-right-wrap clearfix kingster-item-mglr kingster-navigation-top">
                                    <div class="kingster-main-menu-search" id="kingster-top-search"><i class="icon_search"></i></div>
                                    <div class="kingster-top-search-wrap">
                                        <div class="kingster-top-search-close"></div>

                                        <div class="kingster-top-search-row">
                                            <div class="kingster-top-search-cell">
                                                <form role="search" method="get" class="search-form" action="#">
                                                    <input type="text" class="search-field kingster-title-font" placeholder="Search..." value="" name="s" />
                                                    <div class="kingster-top-search-submit"><i class="fa fa-search"></i></div>
                                                    <input type="submit" class="search-submit" value="Search" />
                                                    <div class="kingster-top-search-close"><i class="icon_close"></i></div>
                                                    <input type="hidden" name="ref" value="course" /><input type="hidden" name="post_type" value="lp_course" />
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                            <!-- kingster-navigation -->
                        </div>
                        <!-- kingster-header-inner -->
                    </div>
                    <!-- kingster-header-container -->
                </header>