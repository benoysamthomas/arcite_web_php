      <div class="kingster-top-bar">
                    <div class="kingster-top-bar-background"></div>
                    <div class="kingster-top-bar-container kingster-container">
                        <div class="kingster-top-bar-container-inner clearfix">
                            <div class="kingster-top-bar-left kingster-item-pdlr">
                               <!-- <a href="#" style="margin-right: 30px;">Campus</a><a href="#" style="margin-right: 30px;">Documentation</a>--><a href="<?php echo base_url(); ?>login" target="_blank" style="margin-right: 30px;">Login</a>
                            </div>
						
                            <div class="kingster-top-bar-right kingster-item-pdlr">
                                <div class="kingster-top-bar-right-text"><span style="color: #8dd7e5; margin-right: 30px;"><i class="fa fa-phone"></i> +91 808-996-2794</span><a href="https://wa.me/919633738601" target="_blank" ><i class="fa fa-whatsapp"> +91  963 373 8601</i></a></div>
                                <div class="kingster-top-bar-right-social">
                                    <a href="https://m.facebook.com/102869268617007/" target="_blank" class="kingster-top-bar-social-icon" title="facebook"><i class="fa fa-facebook"></i></a>
                                    <a href="https://twitter.com/arcinstitutein1" target="_blank" class="kingster-top-bar-social-icon" title="twitter"><i class="fa fa-twitter"></i></a>
                                    <a href="https://instagram.com/arcite_competitive_exams?igshid=YmMyMTA2M2Y=" target="_blank" class="kingster-top-bar-social-icon" title="instagram"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>